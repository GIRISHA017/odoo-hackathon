import GoTrueClient from './GoTrueClient'

const AuthClient = GoTrueClient

export default AuthClient
