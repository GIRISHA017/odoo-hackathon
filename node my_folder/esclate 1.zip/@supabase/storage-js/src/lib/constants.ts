import { version } from './version'
export const DEFAULT_HEADERS = { 'X-Client-Info': `storage-js/${version}` }
