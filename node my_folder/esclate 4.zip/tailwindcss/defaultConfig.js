let defaultConfig = require('./lib/public/default-config')
module.exports = (defaultConfig.__esModule ? defaultConfig : { default: defaultConfig }).default
