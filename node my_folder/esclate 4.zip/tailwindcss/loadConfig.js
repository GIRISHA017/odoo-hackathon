let loadConfig = require('./lib/public/load-config')
module.exports = (loadConfig.__esModule ? loadConfig : { default: loadConfig }).default
